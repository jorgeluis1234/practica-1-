
package pratica1;


public class Pratica1 {
 static void main(String[] args) {
        
        FrmPrincipal.main(args);
    }
    
}
